import React, { Component } from 'react'

 class Buy extends Component {
  render() {
    return (
      <div>
        <p>The products have been bought</p>
      </div>
    )
  }
}


export default Buy;