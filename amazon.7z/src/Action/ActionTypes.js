export const ADD ='ADD';
export const REM ='REM';

export const REDIRECT_CART='REDIRECT_CART';
export const BUY='BUY';